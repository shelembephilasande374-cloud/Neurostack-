# NeuroStack

Turn your notes into flashcards and summaries using Gemini AI.

## Deploy in 5 minutes

### 1. Upload to GitHub
- Create a new repository on github.com
- Upload all these files (drag and drop the folder)

### 2. Deploy to Vercel
- Go to vercel.com and sign in with GitHub
- Click "Add New Project"
- Select your neurostack repository
- Click "Deploy"

### 3. Add your Gemini API key
- In Vercel, go to your project → Settings → Environment Variables
- Add a new variable:
  - Name:  GEMINI_API_KEY
  - Value: (paste your key from aistudio.google.com)
- Click Save, then go to Deployments → Redeploy

### 4. Done!
Your app is live at yourproject.vercel.app

## Local development
```
npm install
npm run dev
```
Then open http://localhost:3000

Add a `.env.local` file with:
```
GEMINI_API_KEY=your_key_here
```
